# integration-test-repo-demo
A demo of integration with Github

[![Build Status](https://travis-ci.org/danielstern/integration-test-repo-demo.svg?branch=master)](https://travis-ci.org/danielstern/integration-test-repo-demo)

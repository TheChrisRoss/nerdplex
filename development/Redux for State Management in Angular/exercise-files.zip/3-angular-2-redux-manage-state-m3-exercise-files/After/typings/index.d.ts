/// <reference path="modules/deep-freeze/index.d.ts" />

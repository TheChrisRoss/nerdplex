/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ToastComponent } from './toast.component';

describe('Component: Toast', () => {
  it('should create an instance', () => {
    let component = new ToastComponent();
    expect(component).toBeTruthy();
  });
});

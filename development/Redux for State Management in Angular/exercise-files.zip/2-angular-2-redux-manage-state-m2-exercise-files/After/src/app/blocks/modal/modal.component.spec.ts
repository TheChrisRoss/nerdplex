/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ModalComponent } from './modal.component';

describe('Component: Modal', () => {
  it('should create an instance', () => {
    let component = new ModalComponent();
    expect(component).toBeTruthy();
  });
});

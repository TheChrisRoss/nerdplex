/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { FilterTextComponent } from './filter-text.component';

describe('Component: FilterText', () => {
  it('should create an instance', () => {
    let component = new FilterTextComponent();
    expect(component).toBeTruthy();
  });
});

﻿using Microsoft.Azure.Documents.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Threading.Tasks;

namespace DocDb.Partitioning
{
	public static class LookupPartitioningDemo
	{
		public async static Task Run()
		{
			Debugger.Break();

			var endpoint = ConfigurationManager.AppSettings["DocDbEndpoint"];
			var masterKey = ConfigurationManager.AppSettings["DocDbMasterKey"];

			var map = new Dictionary<string, string>();
			map.Add("tenant1", "coll1");
			map.Add("tenant2", "coll1");
			map.Add("tenant3", "coll2");
			map.Add("tenant4", "coll2");
			map.Add("tenant5", "coll2");
			map.Add("tenant6", "coll3");

			using (var client = new DocumentClient(new Uri(endpoint), masterKey))
			{
				var database = await Helpers.GetDatabaseAsync(client, "mydb");
				var lookupResolver = new LookupPartitionResolver<string>("tenantId", map);
				client.PartitionResolvers[database.SelfLink] = lookupResolver;
				System.Diagnostics.Debugger.Break();
			}
		}

	}

}

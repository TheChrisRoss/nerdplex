﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocDb.Partitioning
{
	public class SpilloverPartitionResolver : IPartitionResolver
	{
		public SpilloverPartitionResolver(
			DocumentClient client,
			Database database,
			DocumentCollectionSpec collectionSpec = null,
			string collectionIdPrefix = "Collection.",
			double fillFactor = 0.90,
			double checkIntervalSeconds = 3600)
		{
			this.Client = client;
			this.Database = database;
			this.CollectionTemplate = collectionSpec;
			this.CollectionLinks = GetCollections(client, database, collectionIdPrefix, collectionSpec);
			this.CollectionIdPrefix = collectionIdPrefix;
			this.FillFactor = fillFactor;
			this.CheckInterval = TimeSpan.FromSeconds(checkIntervalSeconds);
		}

		public DocumentClient Client { get; private set; }
		public Database Database { get; private set; }
		public List<string> CollectionLinks { get; set; }
		public string CollectionIdPrefix { get; private set; }
		public DocumentCollectionSpec CollectionTemplate { get; private set; }
		public double FillFactor { get; private set; }
		public TimeSpan CheckInterval { get; private set; }
		public DateTime LastCheckTimeUtc { get; private set; }

		public IEnumerable<string> ResolveForRead(object partitionKey)
		{
			this.CreateCollectionIfRequired();
			return this.CollectionLinks;
		}

		public string ResolveForCreate(object partitionKey)
		{
			this.CreateCollectionIfRequired();
			return this.CollectionLinks.Last();
		}

		public object GetPartitionKey(object document)
		{
			return null;
		}

		private static List<string> GetCollections(
			DocumentClient client,
			Database database,
			string collectionIdPrefix,
			DocumentCollectionSpec spec)
		{
			var collections = new Dictionary<int, string>();
			foreach (DocumentCollection collection in client.ReadDocumentCollectionFeedAsync(database.SelfLink).Result)
			{
				if (collection.Id.StartsWith(collectionIdPrefix))
				{
					int collectionNumber = int.Parse(collection.Id.Replace(collectionIdPrefix, string.Empty));
					collections[collectionNumber] = collection.SelfLink;
				}
			}

			// Return selflinks in ID order
			return collections.OrderBy(kvp => kvp.Key).Select(kvp => kvp.Value).ToList();
		}

		private void CreateCollectionIfRequired()
		{
			if (this.ShouldCreateCollection())
			{
				string collectionId = string.Format("{0}{1}", this.CollectionIdPrefix, this.CollectionLinks.Count);
				var createdCollection = Helpers.GetCollectionAsync(this.Client, this.Database, collectionId, this.CollectionTemplate).Result;
				this.CollectionLinks.Add(createdCollection.SelfLink);
			}
		}

		private bool ShouldCreateCollection()
		{
			if (this.CollectionLinks.Count == 0)
			{
				return true;
			}

			string lastCollectionLink = this.CollectionLinks.Last();
			if (this.LastCheckTimeUtc == null || DateTime.UtcNow >= this.LastCheckTimeUtc.Add(this.CheckInterval))
			{
				ResourceResponse<DocumentCollection> response = this.Client.ReadDocumentCollectionAsync(lastCollectionLink).Result;
				this.LastCheckTimeUtc = DateTime.UtcNow;
				if (response.CollectionSizeUsage >= response.CollectionSizeQuota * this.FillFactor)
				{
					return true;
				}
			}

			return false;
		}
	}

	public class DocumentCollectionSpec
	{
		public IndexingPolicy IndexingPolicy { get; set; }
		public string OfferType { get; set; }
		public IList<StoredProcedure> StoredProcedures { get; set; }
		public IList<Trigger> Triggers { get; set; }
		public IList<UserDefinedFunction> UserDefinedFunctions { get; set; }
	}

}

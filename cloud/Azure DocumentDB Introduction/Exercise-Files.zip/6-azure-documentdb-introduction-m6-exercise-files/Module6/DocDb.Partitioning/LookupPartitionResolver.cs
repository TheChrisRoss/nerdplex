﻿using Microsoft.Azure.Documents.Partitioning;
using System;
using System.Collections.Generic;

namespace DocDb.Partitioning
{
	public class LookupPartitionResolver<T> : RangePartitionResolver<T>
		where T : IComparable<T>, IEquatable<T>
	{
		public LookupPartitionResolver(string partitionKeyPropertyName, IDictionary<T, string> partitionMap)
			: base(partitionKeyPropertyName, BuildRangePartitionMap(partitionMap))
		{
		}

		private static IDictionary<Range<T>, string> BuildRangePartitionMap(IDictionary<T, string> partitionMap)
		{
			if (partitionMap == null)
			{
				throw new ArgumentNullException("partitionMap");
			}

			Dictionary<Range<T>, string> rangePartitionMap = new Dictionary<Range<T>, string>();
			foreach (T key in partitionMap.Keys)
			{
				rangePartitionMap[new Range<T>(key)] = partitionMap[key];
			}

			return rangePartitionMap;
		}
	}
}

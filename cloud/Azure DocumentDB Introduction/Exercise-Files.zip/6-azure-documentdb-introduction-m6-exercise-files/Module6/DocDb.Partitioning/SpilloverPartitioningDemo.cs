﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using System;
using System.Configuration;
using System.Diagnostics;
using System.Threading.Tasks;

namespace DocDb.Partitioning
{
	public static class SpilloverPartitioningDemo
	{
		public async static Task Run()
		{
			Debugger.Break();

			var endpoint = ConfigurationManager.AppSettings["DocDbEndpoint"];
			var masterKey = ConfigurationManager.AppSettings["DocDbMasterKey"];

			using (var client = new DocumentClient(new Uri(endpoint), masterKey))
			{
				var database = await Helpers.GetDatabaseAsync(client, "mydb");
				var spilloverResolver = new SpilloverPartitionResolver(client, database);
				client.PartitionResolvers[database.SelfLink] = spilloverResolver;

				dynamic documentDef = new { name = "Dummy document", text = new string('.', 40000) };
				for (var i = 0; i < 1000; i++)
				{
					var resp = await client.CreateDocumentAsync(database.SelfLink, documentDef);
				}
			}
		}

	}
}

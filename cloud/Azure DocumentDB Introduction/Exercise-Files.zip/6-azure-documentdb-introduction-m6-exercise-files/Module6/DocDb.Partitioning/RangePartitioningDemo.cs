﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using Microsoft.Azure.Documents.Partitioning;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace DocDb.Partitioning
{
	public static class RangePartitioningDemo
	{
		public async static Task Run()
		{
			Debugger.Break();

			var endpoint = ConfigurationManager.AppSettings["DocDbEndpoint"];
			var masterKey = ConfigurationManager.AppSettings["DocDbMasterKey"];

			using (var client = new DocumentClient(new Uri(endpoint), masterKey))
			{
				await CreateCollections(client);

				RegisterRangeResolver(client);

				await CreateDocumentsAcrossPartitions(client);
				QueryDocumentsAcrossPartitions(client);

				await DeleteCollections(client);
			}
		}

		private static async Task CreateCollections(DocumentClient client)
		{
			await client.CreateDocumentCollectionAsync("dbs/mydb", new DocumentCollection { Id = "CollectionAM" });
			await client.CreateDocumentCollectionAsync("dbs/mydb", new DocumentCollection { Id = "CollectionNZ" });
		}

		private static async Task CreateDocumentsAcrossPartitions(DocumentClient client)
		{
			Console.WriteLine();
			Console.WriteLine(">>> Create Documents Across Partitions <<<");

			var kirkDocument = await client.CreateDocumentAsync("dbs/mydb", new { userId = "Kirk", title = "Captain" });
			Console.WriteLine("Document 1: {0}", kirkDocument.Resource.SelfLink);

			var spockDocument = await client.CreateDocumentAsync("dbs/mydb", new { userId = "Spock", title = "Science Officer" });
			Console.WriteLine("Document 2: {0}", spockDocument.Resource.SelfLink);
		}

		private static void QueryDocumentsAcrossPartitions(DocumentClient client)
		{
			dynamic kirkDocument = client
				.CreateDocumentQuery<object>("dbs/mydb", "SELECT * FROM c WHERE c.userId =  'Kirk'", null, "Kirk")
				.AsEnumerable()
				.First();

			dynamic spockDocument = client
				.CreateDocumentQuery<object>("dbs/mydb", "SELECT * FROM c WHERE c.userId =  'Spock'", null, "Spock")
				.AsEnumerable()
				.First();

			dynamic allDocuments = client
				.CreateDocumentQuery<object>("dbs/mydb", "SELECT * FROM c")
				.ToList();
		}
		
		private static async Task DeleteCollections(DocumentClient client)
		{
			await client.DeleteDocumentCollectionAsync("dbs/mydb/colls/CollectionAM");
			await client.DeleteDocumentCollectionAsync("dbs/mydb/colls/CollectionNZ");
		}

		private static void RegisterRangeResolver(DocumentClient client)
		{
			// Note: \uffff is the largest UTF8 value, so M\ufff includes all strings that start with M.
			var resolver = new RangePartitionResolver<string>(
				"userId",
				new Dictionary<Range<string>, string>() 
                { 
                    { new Range<string>("A", "M\uffff"), "dbs/mydb/colls/CollectionAM" },
                    { new Range<string>("N", "Z\uffff"), "dbs/mydb/colls/CollectionNZ" },
                });

			client.PartitionResolvers["dbs/mydb"] = resolver;
		}
	
	}

}

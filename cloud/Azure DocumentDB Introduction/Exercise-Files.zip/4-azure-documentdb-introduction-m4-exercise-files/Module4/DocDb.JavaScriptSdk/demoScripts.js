﻿var endpoint = "https://lennilobel.documents.azure.com/";

var demoScripts = {
	authenticate: function (callback) {
		var xhr = new XMLHttpRequest();
		xhr.open("POST", "/api/auth");
		xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xhr.onload = function (e) {
			var authResponse = JSON.parse(xhr.response);
			callback(authResponse);
		};
		xhr.send("username=Kirk&password=kirkpwd");
	},
	masterKeyWontWorkDemo: function () {
		var authKey = "rCtyxsTKxz/ZZ1pQRrQkxLs9+VPMRdf4GbXK8WZZzqg41BKNa4uyXJ4xM4cG2SUwmTyAFRDDkv8zrFtVit91EQ==";
		var client = DocumentDB.createClient(endpoint, { masterKey: authKey });

		var databaseDefinition = { id: "MyJsDatabase" };

		try {
			client.createDatabase(databaseDefinition, null, function (err, createdDatabase) {
				// will never get here; SDK will throw exception using master key for connection
			});
		}
		catch (err) {
			alert(err);
		}
	},
	createDatabase: function () {
		var collectionRid = "eMU5AOVOoAA=";
		var resourceToken = "type=resource&ver=1&sig=WRYFwBlphwebd8E9AgVYeQ==;Vsye3qwQOnm/NiNHrUQOsSQCe7aLsCix0a9f9stc/UcL4zIIy6ttzqnfYZ/AaKVbql5L04+MwFbAcrMOp/hGa0Wlph52M90Fw+fprBIBj+wHrOhYrdlu+QjREKlR8e6GWS4p3eH3rfqS+S8zVR4gRQ9nlkCUHdCodQ/DRjdnDlujjOpBj6WRx8K5Xejooh9CwTJdsaOFmDdWSIyckg/axTbKZ3hyCRmgkiwE0v66+rg=;";
		var resourceTokens = {};
		resourceTokens[collectionRid] = resourceToken;

		var client = DocumentDB.createClient(endpoint, { resourceTokens: resourceTokens });

		var databaseDefinition = { id: "MyJsDatabase" };

		try {
			client.createDatabase(databaseDefinition, null, function (err, createdDatabase) {
				if (err) {
					throw err;
				}
				console.log('result', createdDatabase);
			});
		}
		catch (e) {
			alert(e);
		}
	},
	createDocument: function () {
		this.authenticate(function (authResponse) {
			var resourceTokens = {};
			resourceTokens[authResponse.collectionRid] = authResponse.resourceToken;

			var client = DocumentDB.createClient(endpoint, { resourceTokens: resourceTokens });

			var documentDefinition = {
				id: "MyNodeJsDoc",
				content: "My node.js document!"
			};

			try {
				client.createDocument(authResponse.collectionLink, documentDefinition, function (err, createdDocument, headers) {
					if (err) {
						throw err;
					}
					console.log('Created new document');
					console.log(createdDocument);
				});
			}
			catch (e) {
				alert(e);
			}
		});
	},
};

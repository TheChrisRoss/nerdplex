﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web.Http;

namespace DocDb.JavaScriptSdk.Controllers
{
    public class AuthController : ApiController
    {
		[HttpPost]
		public AuthResponse Authenticate(AuthRequest req)
		{
			// Check credentials
			this.ValidateCredentials(req);

			// Connect with master key to get resource token for response
			var endpoint = ConfigurationManager.AppSettings["DocDbEndpoint"];
			var masterKey = ConfigurationManager.AppSettings["DocDbMasterKey"];

			using (var client = new DocumentClient(new Uri(endpoint), masterKey))
			{
				// Get database
				var database = (Database) client.CreateDatabaseQuery(
					"SELECT * FROM c WHERE c.id = 'mydb'").ToList().First();

				// Get collection
				var collection = (DocumentCollection) client.CreateDocumentCollectionQuery(
					database.CollectionsLink,
					"SELECT * FROM c WHERE c.id = 'mystore'").ToList().First();

				// Get user
				var user = (User) client.CreateUserQuery(
					database.UsersLink,
					"SELECT * FROM c WHERE c.id = '" + req.username + "'").ToList().First();

				// Get user's permission for this collection
				var perm = (Permission) client.CreatePermissionQuery(user.PermissionsLink)
					.ToList()
					.First(p => p.ResourceLink == collection.SelfLink);

				// Return a response with collection link and resource token
				var resp = new AuthResponse
				{
					collectionLink = collection.SelfLink,
					collectionRid = collection.ResourceId,
					resourceToken = perm.Token
				};
				return resp;
			}
		}

		private void ValidateCredentials(AuthRequest req)
		{
			// Check credentials (bogus dictionary here, but could be anything... database lookup, active directory, etc.)

			var userPasswordDirectory = new Dictionary<string, string>();
			userPasswordDirectory.Add("Kirk", "kirkpwd");
			userPasswordDirectory.Add("Spock", "spockpwd");

			var username = req.username;
			var password = req.password;

			if (!userPasswordDirectory.Keys.Contains(username))
			{
				throw new Exception(string.Format("No such user: {0}", username));
			}

			if (userPasswordDirectory[username] != password)
			{
				throw new Exception(string.Format("Wrong password for user: {0}", username));
			}
		}
	}

	public class AuthRequest
	{
		public string username { get; set; }
		public string password { get; set; }
	}
	
	public class AuthResponse
    {
		public string resourceToken { get; set; }
		public string collectionLink { get; set; }
		public string collectionRid { get; set; }
    }
}

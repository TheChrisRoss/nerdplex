﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace DocDb.RestApi
{
	class Program
	{
		static void Main(string[] args)
		{
			Task.Run(async () =>
			{
				Debugger.Break();

				await ViewDatabases();

				await CreateDatabase();
				await ViewDatabases();

				await DeleteDatabase();

			}).Wait();
		}

		private async static Task ViewDatabases()
		{
			Console.WriteLine();
			Console.WriteLine(">>> View Databases <<<");

			var result = await makeRestCall(HttpMethod.Get, "dbs", "dbs");

			var databases = result.Databases as IEnumerable<dynamic>;
			foreach (var database in databases)
			{
				Console.WriteLine(" Database Id: {0}; Rid: {1}", database.id, database._rid);
			}
		}

		private async static Task CreateDatabase()
		{
			Console.WriteLine();
			Console.WriteLine(">>> Create Database <<<");

			var result = await makeRestCall(HttpMethod.Post, "dbs", "dbs", "", @"{""id"":""MyNewDatabase""}");
			Console.WriteLine(result);
		}

		private async static Task DeleteDatabase()
		{
			Console.WriteLine();
			Console.WriteLine(">>> Delete Database <<<");

			var result = await makeRestCall(HttpMethod.Get, "dbs", "dbs");

			var databases = result.Databases as IEnumerable<dynamic>;
			var database = databases.Single(db => db.id == "MyNewDatabase");
			var resourceId = database._rid.ToString();
			var selfLink = database._self.ToString();

			await makeRestCall(HttpMethod.Delete, "dbs", selfLink, resourceId);
		}

		private static async Task<dynamic> makeRestCall(
			HttpMethod method,
			string resourceType,
			string selfLink,
			string resourceId = "",
			string content = null)
		{
			Console.Write("REST API request... ");

			// The current time (GMT) is needed for both hashing the authorization token and setting the x-ms-date HTTP header
			var gmt = DateTime.UtcNow.ToString("r");

			// Generate the authorization header by hashing a request payload using the master key
			var authVerb = method.ToString().ToLower();
			var authSigPayload = string.Format("{0}\n{1}\n{2}\n{3}\n\n", authVerb, resourceType, resourceId, gmt).ToLower();
			var masterKey = ConfigurationManager.AppSettings["DocDbMasterKey"];
			var masterKeyCrypto = new HMACSHA256(Convert.FromBase64String(masterKey));
			var authSig = Convert.ToBase64String(masterKeyCrypto.ComputeHash(Encoding.UTF8.GetBytes(authSigPayload)));
			var authHeader = Uri.EscapeDataString(string.Format("type=master&ver=1.0&sig={0}", authSig));

			// Make the call over HTTP
			using (var client = new HttpClient())
			{
				var url = ConfigurationManager.AppSettings["DocDbEndpoint"] + selfLink;
				using (var request = new HttpRequestMessage(method, url))
				{
					request.Headers.Add("authorization", authHeader);
					request.Headers.Add("x-ms-version", "2015-04-08");
					request.Headers.Add("x-ms-date", gmt);
					if (content != null)
					{
						request.Content = new StringContent(content);
					}

					var response = await client.SendAsync(request);
					Console.WriteLine(" response status: {0}", response.StatusCode);
					var responseData = (dynamic)await response.Content.ReadAsAsync<object>();	// Requires System.Net.Http.Formatting extensions

					return responseData;
				}
			}
		}

	}

}

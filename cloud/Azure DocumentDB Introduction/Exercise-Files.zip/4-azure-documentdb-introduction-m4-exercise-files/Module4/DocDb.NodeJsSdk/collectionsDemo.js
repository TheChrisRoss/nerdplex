﻿var DocumentClient = require("documentdb").DocumentClient;

console.log('DocumentDB Node.js SDK collections demo')

var endpoint = "https://pluralsightdemos.documents.azure.com/";
var authKey = "4Uwjp4tUp9w24q4d+OIly35icR3nTxldFwW9IpKoMcLZTxoac1ZcCWq9L/OnP40EnFZ69vktU3gYPuPmzc5plA==";

var client = new DocumentClient(endpoint, { masterKey: authKey });
var databaseLink;

// get database link
var results = client.queryDatabases("SELECT VALUE c._self FROM c WHERE c.id = 'mydb'");
results.toArray(function (err, databaseLinks) {
    if (err) throw err.body;
    databaseLink = databaseLinks[0];
    
    // create/query/delete collections
    viewCollections(function () {
        createCollection("MyCollection1", function () {
            createCollection("MyCollection2", function () {
                viewCollections(function () {
                    deleteCollection("MyCollection1", function () {
                        deleteCollection("MyCollection2", function () {
                            console.log();
                            console.log("Done. Press CTRL+C to continue...");
                        });
                    });
                });
            });
        });
    });
});

function viewCollections(callback) {
    console.log();
    console.log(">>> View Collections <<<");
    
    var results = client.queryCollections(databaseLink, "SELECT * FROM c");
    results.toArray(function (err, collections) {
        if (err) throw err.body;
        collections.forEach(function (collection, i) {
            console.log("Collection #" + (i + 1));
            console.log(collection);
        });
        callback();
    });
}

function createCollection(collectionId, callback) {
    console.log();
    console.log(">>> Create Collection " + collectionId + " <<<");
    
    var collectionDefinition = { id: collectionId };
    client.createCollection(databaseLink, collectionDefinition, null, function (err, collection) {
        if (err) throw err.body;
        console.log("Created new collection");
        console.log(collection);
        callback();
    });
}

function deleteCollection(collectionId, callback) {
    console.log();
    console.log(">>> Delete Collection " + collectionId + " <<<");
    
    var querySpec = {
        query: "SELECT VALUE c._self FROM c WHERE c.id = @id",
        parameters: [{ name: "@id", value: collectionId }]
    };
    client.queryCollections(databaseLink, querySpec).toArray(function (err, collectionLinks) {
        if (err) throw err.body;
        var collectionLink = collectionLinks[0];
        client.deleteCollection(collectionLink, function (err) {
            if (err) throw err.body;
            console.log("Deleted collection");
            callback();
        });
    });
}

﻿var DocumentClient = require("documentdb").DocumentClient;

var endpoint = "https://pluralsightdemos.documents.azure.com/";
var authKey = "4Uwjp4tUp9w24q4d+OIly35icR3nTxldFwW9IpKoMcLZTxoac1ZcCWq9L/OnP40EnFZ69vktU3gYPuPmzc5plA==";

var client = new DocumentClient(endpoint, { "masterKey": authKey });

// Create a database
var databaseDefinition = { id: "mydb_nodejs" };
client.createDatabase(databaseDefinition, function (err, database) {
    if (err) throw err;
    // Create a collection    
    var collectionDefinition = { id: "mycoll" };
    client.createCollection(database._self, collectionDefinition, function (err, collection) {
        if (err) throw err;
        // Create a document        
        var documentDefinition = {
            id: "SMITHJ",
            name: "John Smith",
            dob: "1964-30-08",
            holdings: [
                { qty: 100, symbol: "MSFT" },
                { qty: 75, symbol: "WMT" }
            ]
        };
        client.createDocument(collection._self, documentDefinition, function (err, document) {
            if (err) throw err;
            // Query for document
            client.queryDocuments(collection._self, "SELECT * FROM c WHERE c.id = 'SMITHJ'").toArray(function (err, results) {
                if (err) throw err;
                console.log("Results:");
                console.log(results);
                // Delete the database
                client.deleteDatabase(database._self, function (err) {
                    if (err) throw err;
                    console.log('Done');
                });
            });
        });
    });
});

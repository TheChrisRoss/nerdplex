﻿var DocumentClient = require("documentdb").DocumentClient;

console.log('DocumentDB Node.js SDK documents demo')

var endpoint = "https://pluralsightdemos.documents.azure.com/";
var authKey = "4Uwjp4tUp9w24q4d+OIly35icR3nTxldFwW9IpKoMcLZTxoac1ZcCWq9L/OnP40EnFZ69vktU3gYPuPmzc5plA==";

var client = new DocumentClient(endpoint, { masterKey: authKey });
var databaseLink;
var collectionLink;

// get database link
var results = client.queryDatabases("SELECT VALUE c._self FROM c WHERE c.id = 'mydb'");
results.toArray(function (err, databaseLinks) {
    if (err) throw err.body;
    databaseLink = databaseLinks[0];
    
    // get collection link    
    results = client.queryCollections(databaseLink, "SELECT VALUE c._self FROM c WHERE c.id = 'mystore'");
    results.toArray(function (err, collectionLinks) {
        if (err) throw err.body;
        collectionLink = collectionLinks[0];
        
        // create/query/delete documents        
        createDocuments(function () {
            queryDocuments(function () {
                deleteDocuments(function () {
                    console.log();
                    console.log("Done. Press CTRL+C to continue...");
                });
            });
        });
    });
});

function createDocuments(callback) {
    var documentDefinition = { name: "Node.js customer 1" };
    client.createDocument(collectionLink, documentDefinition, null, function (err, document) {
        if (err) throw err.body;
        console.log('Created new document ' + document.id);
        console.log(document);
        documentDefinition = { name: "Node.js customer 2" };
        client.createDocument(collectionLink, documentDefinition, null, function (err, document) {
            if (err) throw err.body;
            console.log('Created new document ' + document.id);
            console.log(document);
            callback();
        });
    });
};

function queryDocuments(callback) {
    results = client.queryDocuments(collectionLink, "SELECT * FROM c WHERE STARTSWITH(c.name, 'Node.js customer') = true");
    results.toArray(function (err, documents) {
        if (err) throw err.body;
        console.log("Query results: " + documents.length + " document(s)");
        documents.forEach(function (document, i) {
            console.log("Document #" + (i + 1));
            console.log(document);
        });
        callback();
    });
}

function deleteDocuments(callback) {
    results = client.queryDocuments(collectionLink, "SELECT VALUE c._self FROM c WHERE STARTSWITH(c.name, 'Node.js customer') = true");
    results.toArray(function (err, documentLinks) {
        if (err) throw err.body;
        console.log("Found " + documentLinks.length + " document(s) to delete");
        
        var i = 0;
        deleteDocument();        
        
        function deleteDocument() {
            var documentLink = documentLinks[i++];
            client.deleteDocument(documentLink, null, function (err) {
                if (err) throw err.body;
                console.log('Deleted document ' + documentLink);                
                if (i < documentLinks.length) {
                    deleteDocument();
                }
                else {
                    callback();
                }
            });
        }
    });
}


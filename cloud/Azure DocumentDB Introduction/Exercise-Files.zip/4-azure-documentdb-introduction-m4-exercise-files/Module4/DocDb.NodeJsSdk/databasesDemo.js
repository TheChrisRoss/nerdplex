﻿var DocumentClient = require("documentdb").DocumentClient;

console.log('DocumentDB Node.js SDK databases demo')

var endpoint = "https://pluralsightdemos.documents.azure.com/";
var authKey = "4Uwjp4tUp9w24q4d+OIly35icR3nTxldFwW9IpKoMcLZTxoac1ZcCWq9L/OnP40EnFZ69vktU3gYPuPmzc5plA==";

var client = new DocumentClient(endpoint, { masterKey: authKey });

viewDatabases(function () {
    createDatabase("MyNewDatabase", function () {
        viewDatabases(function () {
            deleteDatabase("MyNewDatabase", function () {
                console.log();
                console.log("Done. Press CTRL+C to continue...");
            })
        })
    })
});

function viewDatabases(callback) {
    console.log();
    console.log(">>> View Databases <<<");
    
    var results = client.queryDatabases("SELECT * FROM c");
    results.toArray(function (err, databases) {
        if (err) throw err.body;
        databases.forEach(function (database, i) {
            console.log("Database #" + (i + 1));
            console.log(database);
        });
        callback();
    });
}

function createDatabase(databaseId, callback) {
    console.log();
    console.log(">>> Create Database " + databaseId + " <<<");
    
    var databaseDefinition = { id: databaseId };
    client.createDatabase(databaseDefinition, null, function (err, database) {
        if (err) throw err.body;
        console.log("Created new database");
        console.log(database);
        callback();
    });
}

function deleteDatabase(databaseId, callback) {
    console.log();
    console.log(">>> Delete Database " + databaseId + " <<<");
    
    var querySpec = {
        query: "SELECT VALUE c._self FROM c WHERE c.id = @id",
        parameters: [{ name: "@id", value: databaseId }]
    };
    client.queryDatabases(querySpec).toArray(function (err, databaseLinks) {
        if (err) throw err.body;
        var databaseLink = databaseLinks[0];
        client.deleteDatabase(databaseLink, function (err) {
            if (err) throw err.body;
            console.log("Deleted database");
            callback();
        });
    });
}

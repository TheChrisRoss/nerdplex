﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using System;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace DocDb.StoredProc
{
	class Program
	{
		private static void Main(string[] args)
		{
			Task.Run(async () =>
			{
				await SimpleStoredProcDemo();
			}).Wait();
		}

		private async static Task SimpleStoredProcDemo()
		{
			Debugger.Break();

			var endpoint = ConfigurationManager.AppSettings["DocDbEndpoint"];
			var masterKey = ConfigurationManager.AppSettings["DocDbMasterKey"];

			using (var client = new DocumentClient(new Uri(endpoint), masterKey))
			{
				// Get database
				Database database = client
					.CreateDatabaseQuery("SELECT * FROM c WHERE c.id = 'mydb'")
					.AsEnumerable()
					.First();

				// Get collection
				DocumentCollection collection = client
					.CreateDocumentCollectionQuery(database.CollectionsLink, "SELECT * FROM c WHERE c.id = 'mystore'")
					.AsEnumerable()
					.First();

				// Create stored procedure
				var sprocBody = File.ReadAllText(@"..\..\spHelloWorld.js");

				var sprocDefinition = new StoredProcedure
				{
					Id = "spHelloWorld",
					Body = sprocBody
				};

				StoredProcedure sproc = await client.CreateStoredProcedureAsync(collection.SelfLink, sprocDefinition);
				Console.WriteLine("Created stored procedure {0} ({1})", sproc.Id, sproc.ResourceId);

				// Execute stored procedure
				var result = await client.ExecuteStoredProcedureAsync<string>(sproc.SelfLink);
				Console.WriteLine("Executed stored procedure; response = {0}", result.Response);

				// Delete stored procedure
				await client.DeleteStoredProcedureAsync(sproc.SelfLink);
				Console.WriteLine("Deleted stored procedure {0} ({1})", sproc.Id, sproc.ResourceId);
			}

		}

	}
}

﻿using FireOnWheels.Messages;

namespace FireOnWheels.Dispatch.Helper
{
    public static class EmailSender
    {
        public static void SendEmailToDispatch(DispatchOrderCommand order)
        {
            
        }
    }
}

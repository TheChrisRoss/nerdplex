﻿using System.Threading.Tasks;
using FireOnWheels.Messages;

namespace FireOnWheels.Dispatch.Helper
{
    public static class EmailSender
    {
        public static async Task SendEmailToDispatch(DispatchOrderCommand order)
        {
            
        }
    }
}

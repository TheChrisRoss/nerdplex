﻿using NServiceBus;

namespace FireOnWheels.Messages
{
    public interface IOrderPlannedMessage: IMessage
    {
         
    }
}
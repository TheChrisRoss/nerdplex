﻿using NServiceBus;

namespace FireOnWheels.Messages
{
    public interface IOrderDispatchedMessage: IMessage
    {
         
    }
}
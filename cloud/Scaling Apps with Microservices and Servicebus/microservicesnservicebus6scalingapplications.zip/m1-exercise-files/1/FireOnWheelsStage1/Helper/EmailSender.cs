﻿using FireOnWheelsStage1.Models;

namespace FireOnWheelsStage1.Helper
{
    public static class EmailSender
    {
        public static void SendEmailToDispatch(Order order)
        {
            
        }
    }
}

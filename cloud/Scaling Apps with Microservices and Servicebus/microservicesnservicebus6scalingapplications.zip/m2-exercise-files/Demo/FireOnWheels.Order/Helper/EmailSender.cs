﻿using FireOnWheels.Messages;

namespace FireOnWheels.Order.Helper
{
    public static class EmailSender
    {
        public static void SendEmailToDispatch(ProcessOrderCommand order)
        {
            
        }
    }
}
